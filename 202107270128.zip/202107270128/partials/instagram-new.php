
<!-- instagram -->
<section class="section">
    <div class="section_inner section_inner-wide">

        <div id="instafeed" class="instagram">
        <div class="instagram_list">
            <!-- SnapWidget -->
            <script src="https://snapwidget.com/js/snapwidget.js" defer></script>
            <iframe src="https://snapwidget.com/embed/853472" class="snapwidget-widget" allowtransparency="true" frameborder="0" scrolling="no" style="border:none; overflow:hidden;  width:100%; margin-bottom:-3px;" loading="lazy"></iframe>
            <div class="read-more" data-scroll="once">
                <a href="https://www.instagram.com/aoyamagakuinuniversity/" target="_blank" class="more">
                  <img
									data-original="<?php bloginfo('template_url'); ?>/images/insta-cover.svg"
									alt="instagram"
									class="lazy"
									loading="lazy">
                </a>
            </div>
        </div>

    </div>
</section>
<!-- / instagram -->
